-- Dummy file, only here to add the timer blinds toggle to the menu
--Jevonn was here [MMMMMMM]
return { name = "Timer Mechanics" }
--                   ^^^ M spotted
