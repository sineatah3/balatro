-- dummy file to add https option to mod menu
return { name = "HTTPS Module" }
-- someone should make a system for this, engineers are crying
