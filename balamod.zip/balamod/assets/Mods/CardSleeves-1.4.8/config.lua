return {
    adjust_deck_alignment = true,
    allow_any_sleeve_selection = false,
    sleeve_info_location = 1
}
