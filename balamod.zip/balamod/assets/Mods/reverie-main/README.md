<div align="center">
  <img src="https://dvrp-balatro-mods.pages.dev/images/logos/reverie/3.png" style="width: 400px; margin-bottom: 1rem;" />

  # Reverie 🎥

  A movie-themed [Balatro](https://store.steampowered.com/app/2379780/Balatro/) expansion that focuses on providing special shops and various contents around it

  [![GitHub release (latest by date)](https://img.shields.io/github/v/release/dvrp0/reverie)](https://github.com/dvrp0/reverie/releases)
</div>