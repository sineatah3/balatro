return {
    jokerdisplay_compat = true,
    custom_morsel_compat = true,
    tag_packs_shop = false,
    crazy_packs_shop = false,
    cartomancer_compat = true
}