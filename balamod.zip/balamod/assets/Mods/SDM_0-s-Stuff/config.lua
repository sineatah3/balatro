return {
    sdm_jokers = true,
    sdm_consus = true,
    sdm_decks = true,
    limit_moon_base = true,
}