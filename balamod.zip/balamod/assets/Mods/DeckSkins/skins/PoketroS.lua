local skin = {
    name = "Poketro Spades",
    suit = "spades",
    texture = "PoketroS.png",
    highContrastTexture = nil
}

return skin