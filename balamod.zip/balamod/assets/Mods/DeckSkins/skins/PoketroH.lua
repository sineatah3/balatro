local skin = {
    name = "Poketro Hearts",
    suit = "hearts",
    texture = "PoketroH.png",
    highContrastTexture = nil
}

return skin