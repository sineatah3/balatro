
local skin = {

    name = "bocchi",
    suit = "*",
    cards = {'J', 'Q', 'K', 'A'},
	texture = "bocchi_lc.png",
    highContrastTexture = "bocchi_hc.png"

}


return skin