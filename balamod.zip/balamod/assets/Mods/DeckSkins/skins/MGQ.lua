
local skin = {

    name = "MGQ",
    suit = "*",
    cards = {'J', 'Q', 'K', 'A'},
	texture = "mgq_atlas_lc.png",
    highContrastTexture = "mgq_atlas_hc.png"

}


return skin