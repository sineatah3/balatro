
local skin = {

    name = "Touhou",
    suit = "*",
    cards = {'J', 'Q', 'K', 'A'},
	texture = "touhou_lc.png",
    highContrastTexture = "touhou_hc.png"

}


return skin