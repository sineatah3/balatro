
local skin = {

    name = "Niyog",
    suit = "*",
    cards = {'J', 'Q', 'K', 'A'},
	texture = "templatecards_lc.png",
    highContrastTexture = "templatecards_hc.png"

}


return skin