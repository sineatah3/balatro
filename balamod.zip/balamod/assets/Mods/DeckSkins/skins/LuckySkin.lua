
local skin = {

    name = "Lucky Star",
    suit = "*",
    cards = {'J', 'Q', 'K', 'A'},
	texture = "lucky_lc.png",
    highContrastTexture = "lucky_hc.png"

}


return skin