local skin = {
    name = "Poketro Diamonds",
    suit = "diamonds",
    texture = "PoketroD.png",
    highContrastTexture = nil
}

return skin