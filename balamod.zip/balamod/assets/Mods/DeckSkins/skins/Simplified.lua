local skin = {
    name = "Simplified",
    suit = "*",
    texture = "simplified.png",
    highContrastTexture = "simplified_hc.png",
}


return skin