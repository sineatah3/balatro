local skin = {
    name = "Poketro Clubs",
    suit = "clubs",
    texture = "PoketroC.png",
    highContrastTexture = nil
}

return skin